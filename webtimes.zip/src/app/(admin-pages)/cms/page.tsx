import React from "react";

function CMSHome() {
  return <div>CMS Home page</div>;
}

export default CMSHome;
