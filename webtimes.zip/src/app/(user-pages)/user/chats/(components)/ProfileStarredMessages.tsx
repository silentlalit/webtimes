import React from "react";

const ProfileStarredMessages = () => {
  return <div>ProfileStarredMessages</div>;
};

export default ProfileStarredMessages;
