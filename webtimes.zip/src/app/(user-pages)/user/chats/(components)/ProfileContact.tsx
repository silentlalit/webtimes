import React from "react";

const ProfileContact = () => {
  return <div>ProfileContact</div>;
};

export default ProfileContact;
