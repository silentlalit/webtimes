import React from "react";

const ProfileShared = () => {
  return <div>ProfileShared</div>;
};

export default ProfileShared;
