"use client";

import React from "react";

function UserPage() {
  return <div>User Page</div>;
}

export default UserPage;
