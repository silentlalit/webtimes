import React from "react";

const Page = () => {
  return <div>Edit profile</div>;
};

export default Page;
